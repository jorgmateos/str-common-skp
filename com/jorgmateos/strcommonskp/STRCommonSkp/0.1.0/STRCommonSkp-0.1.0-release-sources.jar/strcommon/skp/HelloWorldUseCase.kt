package strcommon.skp

import skip.lib.*

import skip.foundation.*
interface HelloWorldUseCaseProtocol {
    fun execute(): String
}
@androidx.annotation.Keep
class HelloWorldUseCase: strcommon.skp.HelloWorldUseCaseProtocol, skip.bridge.SwiftPeerBridged, skip.lib.SwiftProjecting {
    var Swift_peer: skip.bridge.SwiftObjectPointer = skip.bridge.SwiftObjectNil

    constructor(Swift_peer: skip.bridge.SwiftObjectPointer, marker: skip.bridge.SwiftPeerMarker?) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = skip.bridge.SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: skip.bridge.SwiftObjectPointer)

    override fun Swift_peer(): skip.bridge.SwiftObjectPointer = Swift_peer

    override fun equals(other: Any?): Boolean {
        if (other !is skip.bridge.SwiftPeerBridged) return false
        return Swift_peer == other.Swift_peer()
    }

    override fun hashCode(): Int = Swift_peer.hashCode()

    constructor() {
        Swift_peer = Swift_constructor_0()
    }
    private external fun Swift_constructor_0(): skip.bridge.SwiftObjectPointer
    override fun execute(): String = Swift_execute_1(Swift_peer)
    private external fun Swift_execute_1(Swift_peer: skip.bridge.SwiftObjectPointer): String

    override fun Swift_projection(options: Int): () -> Any = Swift_projectionImpl(options)
    private external fun Swift_projectionImpl(options: Int): () -> Any

    @androidx.annotation.Keep
    companion object {
    }
}
