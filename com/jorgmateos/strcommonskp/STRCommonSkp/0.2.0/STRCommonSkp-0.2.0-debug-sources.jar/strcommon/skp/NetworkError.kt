package strcommon.skp

import skip.lib.*

@androidx.annotation.Keep
sealed class NetworkError: Exception(), Error, skip.lib.SwiftProjecting {

    class InvalidURLCase: NetworkError() {
        override fun equals(other: Any?): Boolean = other is InvalidURLCase
        override fun hashCode(): Int = "InvalidURLCase".hashCode()
    }
    class InvalidResponseCase: NetworkError() {
        override fun equals(other: Any?): Boolean = other is InvalidResponseCase
        override fun hashCode(): Int = "InvalidResponseCase".hashCode()
    }
    class DecodingCase: NetworkError() {
        override fun equals(other: Any?): Boolean = other is DecodingCase
        override fun hashCode(): Int = "DecodingCase".hashCode()
    }

    override fun Swift_projection(options: Int): () -> Any = Swift_projectionImpl(options)
    private external fun Swift_projectionImpl(options: Int): () -> Any

    @androidx.annotation.Keep
    companion object {
        val invalidURL: NetworkError
            get() = InvalidURLCase()
        val invalidResponse: NetworkError
            get() = InvalidResponseCase()
        val decoding: NetworkError
            get() = DecodingCase()
    }
}
