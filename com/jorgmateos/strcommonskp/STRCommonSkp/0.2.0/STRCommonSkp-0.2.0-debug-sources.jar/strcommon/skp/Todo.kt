package strcommon.skp

import skip.lib.*

@androidx.annotation.Keep
class Todo: skip.bridge.SwiftPeerBridged, skip.lib.SwiftProjecting {
    var Swift_peer: skip.bridge.SwiftObjectPointer = skip.bridge.SwiftObjectNil

    constructor(Swift_peer: skip.bridge.SwiftObjectPointer, marker: skip.bridge.SwiftPeerMarker?) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = skip.bridge.SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: skip.bridge.SwiftObjectPointer)

    override fun Swift_peer(): skip.bridge.SwiftObjectPointer = Swift_peer

    override fun hashCode(): Int = Swift_peer.hashCode()

    val id: Int
        get() = Swift_id(Swift_peer)
    private external fun Swift_id(Swift_peer: skip.bridge.SwiftObjectPointer): Int
    val userId: Int
        get() = Swift_userId(Swift_peer)
    private external fun Swift_userId(Swift_peer: skip.bridge.SwiftObjectPointer): Int
    val title: String
        get() = Swift_title(Swift_peer)
    private external fun Swift_title(Swift_peer: skip.bridge.SwiftObjectPointer): String
    val isCompleted: Boolean
        get() = Swift_isCompleted(Swift_peer)
    private external fun Swift_isCompleted(Swift_peer: skip.bridge.SwiftObjectPointer): Boolean
    constructor(id: Int, userId: Int, title: String, isCompleted: Boolean) {
        Swift_peer = Swift_constructor_0(id, userId, title, isCompleted)
    }
    private external fun Swift_constructor_0(id: Int, userId: Int, title: String, isCompleted: Boolean): skip.bridge.SwiftObjectPointer
    override fun equals(other: Any?): Boolean {
        if (other === this) return true
        if (other !is Todo) return false
        return Swift_isequal(this, other)
    }
    private external fun Swift_isequal(lhs: Todo, rhs: Todo): Boolean

    override fun Swift_projection(options: Int): () -> Any = Swift_projectionImpl(options)
    private external fun Swift_projectionImpl(options: Int): () -> Any

    @androidx.annotation.Keep
    companion object {
    }
}
