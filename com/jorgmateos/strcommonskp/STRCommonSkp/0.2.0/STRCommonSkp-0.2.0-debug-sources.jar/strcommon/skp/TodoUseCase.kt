package strcommon.skp

import skip.lib.*

import skip.foundation.*
interface TodoUseCaseProtocol {
    suspend fun execute(id: Int): strcommon.skp.Todo
    fun callback_execute(id: Int, f_return_callback: (strcommon.skp.Todo?, Throwable?) -> Unit) {
        Task {
            try {
                f_return_callback(execute(id = id), null)
            } catch(t: Throwable) {
                f_return_callback(null, t)
            }
        }
    }
}
@androidx.annotation.Keep
class TodoUseCase: strcommon.skp.TodoUseCaseProtocol, skip.bridge.SwiftPeerBridged, skip.lib.SwiftProjecting {
    var Swift_peer: skip.bridge.SwiftObjectPointer = skip.bridge.SwiftObjectNil

    constructor(Swift_peer: skip.bridge.SwiftObjectPointer, marker: skip.bridge.SwiftPeerMarker?) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = skip.bridge.SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: skip.bridge.SwiftObjectPointer)

    override fun Swift_peer(): skip.bridge.SwiftObjectPointer = Swift_peer

    override fun equals(other: Any?): Boolean {
        if (other !is skip.bridge.SwiftPeerBridged) return false
        return Swift_peer == other.Swift_peer()
    }

    override fun hashCode(): Int = Swift_peer.hashCode()

    constructor() {
        Swift_peer = Swift_constructor_0()
    }
    private external fun Swift_constructor_0(): skip.bridge.SwiftObjectPointer
    override suspend fun execute(id: Int): strcommon.skp.Todo = Async.run {
        kotlin.coroutines.suspendCoroutine { f_continuation ->
            Swift_callback_execute_1(Swift_peer, id) { f_return, f_error ->
                if (f_error != null) {
                    f_continuation.resumeWith(kotlin.Result.failure(f_error))
                } else {
                    f_continuation.resumeWith(kotlin.Result.success(f_return!!))
                }
            }
        }
    }
    private external fun Swift_callback_execute_1(Swift_peer: skip.bridge.SwiftObjectPointer, id: Int, f_callback: (strcommon.skp.Todo?, Throwable?) -> Unit)

    override fun Swift_projection(options: Int): () -> Any = Swift_projectionImpl(options)
    private external fun Swift_projectionImpl(options: Int): () -> Any

    @androidx.annotation.Keep
    companion object {
    }
}
