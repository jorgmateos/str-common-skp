package skip.android.bridge

import skip.lib.*

// Copyright 2024–2026 Skip
// SPDX-License-Identifier: MPL-2.0
import skip.foundation.*

private val logger: SkipLogger = SkipLogger(subsystem = "skip.android.bridge", category = "AndroidBridge")




/// The entry point from a Kotlin Main.kt into the bridged `SkipAndroidBridge`.
///
/// This class handles the initial Kotlin-side setup of the Swift bridging, which currently
/// just involves loading the specific library and calling the Swift `AndroidBridgeBootstrap.initAndroidBridge()`,
/// which will, in turn, perform all the Foundation-level setup.
@androidx.annotation.Keep
open class AndroidBridge: skip.lib.SwiftProjecting {

    override fun Swift_projection(options: Int): () -> Any = Swift_projectionImpl(options)
    private external fun Swift_projectionImpl(options: Int): () -> Any

    @androidx.annotation.Keep
    companion object: CompanionClass() {
        /// This is called at app initialization time by reflection from the `Main.kt`
        ///
        /// It will look like: `skip.android.bridge.AndroidBridge.initBridge("AppDroidModel")`
        override fun initBridge(libraryNames: String) {
            for (libraryName in libraryNames.split(separator = ",")) {
                try {
                    logger.debug("loading library: ${libraryName}")
                    System.loadLibrary(libraryName)
                } catch (error: Throwable) {
                    @Suppress("NAME_SHADOWING") val error = error.aserror()
                    android.util.Log.e("SkipBridge", "error loading bridge library: ${libraryName}", error as? ErrorException)
                }
            }

            val context = ProcessInfo.processInfo.androidContext.sref()
            AndroidBridgeBootstrap.initAndroidBridge(filesDir = context.getFilesDir().getAbsolutePath(), cacheDir = context.getCacheDir().getAbsolutePath())
        }
    }
    open class CompanionClass {
        open fun initBridge(libraryNames: String) = AndroidBridge.initBridge(libraryNames)
    }
}
@androidx.annotation.Keep
open class AndroidBridgeBootstrap: skip.bridge.SwiftPeerBridged, skip.lib.SwiftProjecting {
    var Swift_peer: skip.bridge.SwiftObjectPointer = skip.bridge.SwiftObjectNil

    constructor(Swift_peer: skip.bridge.SwiftObjectPointer, marker: skip.bridge.SwiftPeerMarker?) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = skip.bridge.SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: skip.bridge.SwiftObjectPointer)

    constructor() {
        Swift_peer = Swift_constructor()
    }
    private external fun Swift_constructor(): skip.bridge.SwiftObjectPointer

    override fun Swift_peer(): skip.bridge.SwiftObjectPointer = Swift_peer

    override fun equals(other: Any?): Boolean {
        if (other !is skip.bridge.SwiftPeerBridged) return false
        return Swift_peer == other.Swift_peer()
    }

    override fun hashCode(): Int = Swift_peer.hashCode()

    override fun Swift_projection(options: Int): () -> Any = Swift_projectionImpl(options)
    private external fun Swift_projectionImpl(options: Int): () -> Any

    @androidx.annotation.Keep
    companion object: CompanionClass() {

        override fun initAndroidBridge(filesDir: String, cacheDir: String): Unit = Swift_Companion_initAndroidBridge_0(filesDir, cacheDir)
        private external fun Swift_Companion_initAndroidBridge_0(filesDir: String, cacheDir: String)
    }
    open class CompanionClass {
        open fun initAndroidBridge(filesDir: String, cacheDir: String) = AndroidBridgeBootstrap.initAndroidBridge(filesDir = filesDir, cacheDir = cacheDir)
    }
}

// URL.applicationSupportDirectory exists in Darwin's Foundation but not in Android's Foundation

