// Copyright 2025–2026 Skip
// SPDX-License-Identifier: MPL-2.0

package skip.android.bridge

import skip.lib.*
import skip.lib.Array

import skip.foundation.*



/// This bridged class gives us efficient access to `skip.foundation.Bundle` without bridging it to native.
@androidx.annotation.Keep
class BundleAccess: skip.lib.SwiftProjecting {

    val bundle: skip.foundation.Bundle

    // Fully-qualify the name here so that it bridges to AnyDynamicObject
    constructor(bundle: skip.foundation.Bundle) {
        this.bundle = bundle.sref()
    }

    constructor(path: String): this(skip.foundation.Bundle(path = path)!!) {
    }

    constructor(url: URL): this(skip.foundation.Bundle(url = url)!!) {
    }

    constructor(): this(skip.foundation.Bundle()) {
    }

    override fun equals(other: Any?): Boolean {
        if (other !is BundleAccess) {
            return false
        }
        val lhs = this
        val rhs = other
        return lhs.bundle == rhs.bundle
    }

    override fun hashCode(): Int {
        var hasher = Hasher()
        hash(into = InOut<Hasher>({ hasher }, { hasher = it }))
        return hasher.finalize()
    }
    fun hash(into: InOut<Hasher>) {
        val hasher = into
        hasher.value.combine(bundle)
    }

    val description: String
        get() = bundle.description

    val bundleURL: URL
        get() = bundle.bundleURL

    val resourceURL: URL?
        get() = bundle.resourceURL

    val bundlePath: String
        get() = bundle.bundlePath

    val resourcePath: String?
        get() = bundle.resourcePath

    fun url(forResource: String? = null, withExtension: String? = null, subdirectory: String? = null, localization: String? = null): URL? {
        val name = forResource
        val ext = withExtension
        val subpath = subdirectory
        val localizationName = localization
        return bundle.url(forResource = name, withExtension = ext, subdirectory = subpath, localization = localizationName)
    }

    fun urls(forResourcesWithExtension: String?, subdirectory: String? = null, localization: String? = null): Array<URL>? {
        val ext = forResourcesWithExtension
        val subpath = subdirectory
        val localizationName = localization
        return bundle.urls(forResourcesWithExtension = ext, subdirectory = subpath, localization = localizationName)
    }

    fun path(forResource: String? = null, ofType: String? = null, inDirectory: String? = null, forLocalization: String? = null): String? {
        val name = forResource
        val ext = ofType
        val subpath = inDirectory
        val localizationName = forLocalization
        return bundle.path(forResource = name, ofType = ext, inDirectory = subpath, forLocalization = localizationName)
    }

    fun paths(forResourcesOfType: String?, inDirectory: String? = null, forLocalization: String? = null): Array<String> {
        val ext = forResourcesOfType
        val subpath = inDirectory
        val localizationName = forLocalization
        return bundle.paths(forResourcesOfType = ext, inDirectory = subpath, forLocalization = localizationName)
    }

    val resourcesIndex: Array<String>
        get() = bundle.resourcesIndex

    val developmentLocalization: String
        get() = bundle.developmentLocalization

    val localizations: Array<String>
        get() = bundle.localizations

    fun localizedString(forKey: String, value: String?, table: String?, locale: Locale? = null): String {
        val key = forKey
        val tableName = table
        return bundle.localizedString(forKey = key, value = value, table = tableName, locale = locale)
    }

    fun localizedBundle(locale: Locale): BundleAccess = BundleAccess(bundle.localizedBundle(locale = locale))

    val bundleIdentifier: String?
        get() = bundle.bundleIdentifier

    val infoDictionary: Dictionary<String, Any>?
        get() = bundle.infoDictionary

    val localizedInfoDictionary: Dictionary<String, Any>?
        get() = bundle.localizedInfoDictionary

    fun object_(forInfoDictionaryKey: String): Any? {
        val key = forInfoDictionaryKey
        return bundle.object_(forInfoDictionaryKey = key)
    }

    override fun Swift_projection(options: Int): () -> Any = Swift_projectionImpl(options)
    private external fun Swift_projectionImpl(options: Int): () -> Any

    @androidx.annotation.Keep
    companion object {
        val main: BundleAccess
            get() = BundleAccess(skip.foundation.Bundle.main)

        fun url(forResource: String?, withExtension: String? = null, subdirectory: String? = null, in_: URL): URL? {
            val name = forResource
            val ext = withExtension
            val subpath = subdirectory
            val bundleURL = in_
            return skip.foundation.Bundle.url(forResource = name, withExtension = ext, subdirectory = subpath, in_ = bundleURL)
        }

        fun urls(forResourcesWithExtension: String?, subdirectory: String?, in_: URL): Array<URL>? {
            val ext = forResourcesWithExtension
            val subpath = subdirectory
            val bundleURL = in_
            return skip.foundation.Bundle.urls(forResourcesWithExtension = ext, subdirectory = subpath, in_ = bundleURL)
        }

        fun path(forResource: String?, ofType: String?, inDirectory: String): String? {
            val name = forResource
            val ext = ofType
            val bundlePath = inDirectory
            return skip.foundation.Bundle.path(forResource = name, ofType = ext, inDirectory = bundlePath)
        }

        fun paths(forResourcesOfType: String?, inDirectory: String): Array<String> {
            val ext = forResourcesOfType
            val bundlePath = inDirectory
            return skip.foundation.Bundle.paths(forResourcesOfType = ext, inDirectory = bundlePath)
        }
    }
}

fun NSLocalizedStringAccess(key: String, tableName: String? = null, bundle: BundleAccess? = null, value: String? = null, comment: String): String {
    return NSLocalizedString(key, tableName = tableName, bundle = bundle?.bundle, value = value, comment = comment)
}

