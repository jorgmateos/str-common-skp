package skip.android.bridge

import skip.lib.*

// Copyright 2025–2026 Skip
// SPDX-License-Identifier: MPL-2.0
import skip.foundation.*


/// This bridged class gives us efficient access to `skip.foundation.UserDefaults` without bridging it to native.
@androidx.annotation.Keep
open class UserDefaultsAccess: skip.lib.SwiftProjecting {
    internal val userDefaults: skip.foundation.UserDefaults

    // Fully-qualify the name here so that it bridges to AnyDynamicObject
    constructor(userDefaults: skip.foundation.UserDefaults) {
        this.userDefaults = userDefaults.sref()
    }

    constructor(suiteName: String?) {
        userDefaults = skip.foundation.UserDefaults(suiteName = suiteName)
    }

    open fun register(defaults: Dictionary<String, Any>) {
        val registrationDictionary = defaults
        userDefaults.register(defaults = registrationDictionary)
    }

    open fun set(value: Int, forKey: String) {
        val defaultName = forKey
        userDefaults.set(value, forKey = defaultName)
    }

    open fun set(value: Float, forKey: String) {
        val defaultName = forKey
        userDefaults.set(value, forKey = defaultName)
    }

    open fun set(value: Boolean, forKey: String) {
        val defaultName = forKey
        userDefaults.set(value, forKey = defaultName)
    }

    open fun set(value: Double, forKey: String) {
        val defaultName = forKey
        userDefaults.set(value, forKey = defaultName)
    }

    open fun set(value: String, forKey: String) {
        val defaultName = forKey
        userDefaults.set(value, forKey = defaultName)
    }

    open fun set(value: Any?, forKey: String) {
        val defaultName = forKey
        userDefaults.set(value, forKey = defaultName)
    }

    open fun removeObject(forKey: String) {
        val defaultName = forKey
        userDefaults.removeObject(forKey = defaultName)
    }

    open fun object_(forKey: String): Any? {
        val defaultName = forKey
        return userDefaults.object_(forKey = defaultName)
    }

    open fun string(forKey: String): String? {
        val defaultName = forKey
        return userDefaults.string(forKey = defaultName)
    }

    open fun double(forKey: String): Double {
        val defaultName = forKey
        return userDefaults.double(forKey = defaultName)
    }

    open fun integer(forKey: String): Int {
        val defaultName = forKey
        return userDefaults.integer(forKey = defaultName)
    }

    open fun float(forKey: String): Float {
        val defaultName = forKey
        return userDefaults.float(forKey = defaultName)
    }

    open fun bool(forKey: String): Boolean {
        val defaultName = forKey
        return userDefaults.bool(forKey = defaultName)
    }

    open fun url(forKey: String): URL? {
        val defaultName = forKey
        return userDefaults.url(forKey = defaultName)
    }

    open fun data(forKey: String): Data? {
        val defaultName = forKey
        return userDefaults.data(forKey = defaultName)
    }

    open fun dictionaryRepresentation(): Dictionary<String, Any> = userDefaults.dictionaryRepresentation()

    override fun Swift_projection(options: Int): () -> Any = Swift_projectionImpl(options)
    private external fun Swift_projectionImpl(options: Int): () -> Any

    @androidx.annotation.Keep
    companion object: CompanionClass() {

        override fun resetStandardUserDefaults(): Unit = skip.foundation.UserDefaults.resetStandardUserDefaults()
    }
    open class CompanionClass {
        open fun resetStandardUserDefaults() = UserDefaultsAccess.resetStandardUserDefaults()
    }
}

