package skip.bridge

import skip.lib.*




/// An opaque reference to a Swift object.
typealias SwiftObjectPointer = Long
val SwiftObjectNil = 0L

/// Return a Swift object pointer to a Kotlin instance, else `SwiftObjectNil`.
fun Swift_peer(of: Any): Long {
    val object_ = of
    val peer = (object_ as? SwiftPeerBridged)?.Swift_peer()
    return peer ?: SwiftObjectNil
}

/// Protocol added to a Kotlin projection type backed by a Swift peer object.
interface SwiftPeerBridged {
    fun Swift_peer(): Long
}

/// Marker type used to guarantee uniqueness of our `Swift_peer` constructor.
class SwiftPeerMarker {

    @androidx.annotation.Keep
    companion object {
    }
}

/// Return a closure that creates a Swift projection of this Kotlin instance, else nil.
fun Swift_projection(of: Any, options: Int): (() -> Any)? {
    val object_ = of
    return (object_ as? skip.lib.SwiftProjecting)?.Swift_projection(options = options)
}

/// Return the Java class name of the given object.
fun javaClassNameOf(object_: Any): String = object_.javaClass.name

/// Return the `BridgedTypes` enum case name for the given Kotlin/Java object's type.
fun bridgedTypeStringOf(object_: Any): String = bridgedTypeOf(object_).name

