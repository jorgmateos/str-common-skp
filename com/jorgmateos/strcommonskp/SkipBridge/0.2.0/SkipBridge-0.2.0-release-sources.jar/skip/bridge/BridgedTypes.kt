package skip.bridge

import skip.lib.*
import skip.lib.Set



enum class BridgedTypes {
    boolean_,
    byte_,
    char_,
    double_,
    float_,
    int_,
    long_,
    short_,
    string_,

    byteArray,
    date,
    flow,
    list,
    locale,
    map,
    number,
    result,
    set,
    throwable,
    uuid,
    uri,

    swiftArray,
    swiftAsyncStream,
    swiftAsyncThrowingStream,
    swiftData,
    swiftDate,
    swiftDictionary,
    swiftLocale,
    swiftResult,
    swiftSet,
    swiftUUID,
    swiftURL,

    other;

    @androidx.annotation.Keep
    companion object {
    }
}

fun bridgedTypeOf(object_: Any): BridgedTypes {
    if ((object_ is SwiftProjecting)) {
        return BridgedTypes.other
    }

    if (object_ is Boolean) {
        return BridgedTypes.boolean_
    } else if (object_ is Byte) {
        return BridgedTypes.byte_
    } else if (object_ is Char) {
        return BridgedTypes.char_
    } else if (object_ is Double) {
        return BridgedTypes.double_
    } else if (object_ is Float) {
        return BridgedTypes.float_
    } else if (object_ is Int) {
        return BridgedTypes.int_
    } else if (object_ is Long) {
        return BridgedTypes.long_
    } else if (object_ is Short) {
        return BridgedTypes.short_
    } else if (object_ is String) {
        return BridgedTypes.string_
    }

    if (object_ is kotlin.ByteArray) {
        return BridgedTypes.byteArray
    } else if (object_ is java.util.Date) {
        return BridgedTypes.date
    } else if (object_ is kotlinx.coroutines.flow.Flow<*>) {
        return BridgedTypes.flow
    } else if (object_ is kotlin.collections.List<*>) {
        return BridgedTypes.list
    } else if (object_ is java.util.Locale) {
        return BridgedTypes.locale
    } else if (object_ is kotlin.collections.Map<*, *>) {
        return BridgedTypes.map
    } else if (object_ is java.lang.Number) {
        return BridgedTypes.number
    } else if (object_ is kotlin.Result<*>) {
        return BridgedTypes.result
    } else if (object_ is kotlin.collections.Set<*>) {
        return BridgedTypes.set
    } else if (object_ is kotlin.Throwable) {
        return BridgedTypes.throwable
    } else if (object_ is java.util.UUID) {
        return BridgedTypes.uuid
    } else if (object_ is java.net.URI) {
        return BridgedTypes.uri
    }

    // Use class name so that we don't have a dependency on Skip libraries for these types
    val className = object_::class.java.name
    when (className) {
        "skip.lib.Array" -> return BridgedTypes.swiftArray
        "skip.lib.AsyncStream" -> return BridgedTypes.swiftAsyncStream
        "skip.lib.AsyncThrowingStream" -> return BridgedTypes.swiftAsyncThrowingStream
        "skip.foundation.Data" -> return BridgedTypes.swiftData
        "skip.foundation.Date" -> return BridgedTypes.swiftDate
        "skip.lib.Dictionary" -> return BridgedTypes.swiftDictionary
        "skip.foundation.Locale" -> return BridgedTypes.swiftLocale
        "skip.lib.Result" -> return BridgedTypes.swiftResult
        "skip.lib.Set" -> return BridgedTypes.swiftSet
        else -> return BridgedTypes.other
    }
}


// MARK: Array


// MARK: AsyncStream



// MARK: Data


// MARK: Date


// MARK: Dictionary


// MARK: Locale


// MARK: NSNumber


// MARK: Result


// MARK: Set


// MARK: UUID


// MARK: URL

