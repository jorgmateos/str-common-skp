package skip.bridge

import skip.lib.*



/// A Swift-backed `kotlin.jvm.functions.Function0` implementor.
class SwiftBackedFunction0<R>: kotlin.jvm.functions.Function0<R>, SwiftPeerBridged {
    private var Swift_peer: Long

    constructor(Swift_peer: Long) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: Long)

    override fun invoke(): R {
        val (value, throwable) = Swift_invoke(Swift_peer)
        if (throwable != null) {
            throw throwable as Throwable
        } else {
            return (value as R).sref()
        }
    }
    private external fun Swift_invoke(Swift_peer: Long): kotlin.Pair<Any?, Throwable>

    override fun Swift_peer(): Long = Swift_peer

    @androidx.annotation.Keep
    companion object {
    }
}

/// A Swift-backed `kotlin.jvm.functions.Function1` implementor.
class SwiftBackedFunction1<P0, R>: kotlin.jvm.functions.Function1<P0, R>, SwiftPeerBridged {
    private var Swift_peer: Long

    constructor(Swift_peer: Long) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: Long)

    override fun invoke(p0: P0): R {
        val (value, throwable) = Swift_invoke(Swift_peer, p0)
        if (throwable != null) {
            throw throwable as Throwable
        } else {
            return (value as R).sref()
        }
    }
    private external fun Swift_invoke(Swift_peer: Long, p0: Any?): kotlin.Pair<Any?, Throwable>

    override fun Swift_peer(): Long = Swift_peer

    @androidx.annotation.Keep
    companion object {
    }
}

/// A Swift-backed `kotlin.jvm.functions.Function2` implementor.
class SwiftBackedFunction2<P0, P1, R>: kotlin.jvm.functions.Function2<P0, P1, R>, SwiftPeerBridged {
    private var Swift_peer: Long

    constructor(Swift_peer: Long) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: Long)

    override fun invoke(p0: P0, p1: P1): R {
        val (value, throwable) = Swift_invoke(Swift_peer, p0, p1)
        if (throwable != null) {
            throw throwable as Throwable
        } else {
            return (value as R).sref()
        }
    }
    private external fun Swift_invoke(Swift_peer: Long, p0: Any?, p1: Any?): kotlin.Pair<Any?, Throwable>

    override fun Swift_peer(): Long = Swift_peer

    @androidx.annotation.Keep
    companion object {
    }
}

/// A Swift-backed `kotlin.jvm.functions.Function3` implementor.
class SwiftBackedFunction3<P0, P1, P2, R>: kotlin.jvm.functions.Function3<P0, P1, P2, R>, SwiftPeerBridged {
    private var Swift_peer: Long

    constructor(Swift_peer: Long) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: Long)

    override fun invoke(p0: P0, p1: P1, p2: P2): R {
        val (value, throwable) = Swift_invoke(Swift_peer, p0, p1, p2)
        if (throwable != null) {
            throw throwable as Throwable
        } else {
            return (value as R).sref()
        }
    }
    private external fun Swift_invoke(Swift_peer: Long, p0: Any?, p1: Any?, p2: Any?): kotlin.Pair<Any?, Throwable>

    override fun Swift_peer(): Long = Swift_peer

    @androidx.annotation.Keep
    companion object {
    }
}

/// A Swift-backed `kotlin.jvm.functions.Function4` implementor.
class SwiftBackedFunction4<P0, P1, P2, P3, R>: kotlin.jvm.functions.Function4<P0, P1, P2, P3, R>, SwiftPeerBridged {
    private var Swift_peer: Long

    constructor(Swift_peer: Long) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: Long)

    override fun invoke(p0: P0, p1: P1, p2: P2, p3: P3): R {
        val (value, throwable) = Swift_invoke(Swift_peer, p0, p1, p2, p3)
        if (throwable != null) {
            throw throwable as Throwable
        } else {
            return (value as R).sref()
        }
    }
    private external fun Swift_invoke(Swift_peer: Long, p0: Any?, p1: Any?, p2: Any?, p3: Any?): kotlin.Pair<Any?, Throwable>

    override fun Swift_peer(): Long = Swift_peer

    @androidx.annotation.Keep
    companion object {
    }
}

/// A Swift-backed `kotlin.jvm.functions.Function5` implementor.
class SwiftBackedFunction5<P0, P1, P2, P3, P4, R>: kotlin.jvm.functions.Function5<P0, P1, P2, P3, P4, R>, SwiftPeerBridged {
    private var Swift_peer: Long

    constructor(Swift_peer: Long) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: Long)

    override fun invoke(p0: P0, p1: P1, p2: P2, p3: P3, p4: P4): R {
        val (value, throwable) = Swift_invoke(Swift_peer, p0, p1, p2, p3, p4)
        if (throwable != null) {
            throw throwable as Throwable
        } else {
            return (value as R).sref()
        }
    }
    private external fun Swift_invoke(Swift_peer: Long, p0: Any?, p1: Any?, p2: Any?, p3: Any?, p4: Any?): kotlin.Pair<Any?, Throwable>

    override fun Swift_peer(): Long = Swift_peer

    @androidx.annotation.Keep
    companion object {
    }
}



/// A Continuation implementation that accepts Swift closures
class SwiftContinuationAdapter<R>: kotlin.coroutines.Continuation<R> {
    private val onSuccess: (R) -> Unit
    private val onError: (Throwable) -> Unit

    constructor(onSuccess: (R) -> Unit, onError: (Throwable) -> Unit) {
        this.onSuccess = onSuccess
        this.onError = onError
    }

    override val context: kotlin.coroutines.CoroutineContext
        get() = kotlin.coroutines.EmptyCoroutineContext

    override fun resumeWith(result: kotlin.Result<R>): Unit = result.fold(onSuccess, onError)

    @androidx.annotation.Keep
    companion object {
    }
}


/// A Swift-backed handler for a Continuation; this is easier than trying to construct a `kotlin.Result` from the JNI side.
class SwiftContinuationWrapper<R> {
    private val continuation: kotlin.coroutines.Continuation<R>

    internal constructor(continuation: kotlin.coroutines.Continuation<R>) {
        this.continuation = continuation.sref()
    }

    fun success(value: R): Unit = continuation.resumeWith(kotlin.Result.success(value))

    fun failure(error: Throwable): Unit = continuation.resumeWith(kotlin.Result.failure(error))

    @androidx.annotation.Keep
    companion object {
    }
}

/// A Swift-backed suspending `kotlin.jvm.functions.Function0` implementor.
class SwiftBackedSuspendFunction0<R>: kotlin.jvm.functions.Function1<kotlin.coroutines.Continuation<R>, Any?>, SwiftPeerBridged {
    private var Swift_peer: Long

    constructor(Swift_peer: Long) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: Long)

    override fun invoke(continuation: kotlin.coroutines.Continuation<R>): Any? {
        Swift_invoke(Swift_peer, SwiftContinuationWrapper(continuation))
        return kotlin.coroutines.intrinsics.COROUTINE_SUSPENDED.sref()
    }
    private external fun Swift_invoke(Swift_peer: Long, continuation: Any?)

    override fun Swift_peer(): Long = Swift_peer

    @androidx.annotation.Keep
    companion object {
    }
}

/// A Swift-backed suspending `kotlin.jvm.functions.Function1` implementor.
class SwiftBackedSuspendFunction1<P0, R>: kotlin.jvm.functions.Function2<P0, kotlin.coroutines.Continuation<R>, Any?>, SwiftPeerBridged {
    private var Swift_peer: Long

    constructor(Swift_peer: Long) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: Long)

    override fun invoke(p0: P0, continuation: kotlin.coroutines.Continuation<R>): Any? {
        Swift_invoke(Swift_peer, p0, SwiftContinuationWrapper(continuation))
        return kotlin.coroutines.intrinsics.COROUTINE_SUSPENDED.sref()
    }
    private external fun Swift_invoke(Swift_peer: Long, p0: Any?, continuation: Any?)

    override fun Swift_peer(): Long = Swift_peer

    @androidx.annotation.Keep
    companion object {
    }
}

/// A Swift-backed suspending `kotlin.jvm.functions.Function2` implementor.
class SwiftBackedSuspendFunction2<P0, P1, R>: kotlin.jvm.functions.Function3<P0, P1, kotlin.coroutines.Continuation<R>, Any?>, SwiftPeerBridged {
    private var Swift_peer: Long

    constructor(Swift_peer: Long) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: Long)

    override fun invoke(p0: P0, p1: P1, continuation: kotlin.coroutines.Continuation<R>): Any? {
        Swift_invoke(Swift_peer, p0, p1, SwiftContinuationWrapper(continuation))
        return kotlin.coroutines.intrinsics.COROUTINE_SUSPENDED.sref()
    }
    private external fun Swift_invoke(Swift_peer: Long, p0: Any?, p1: Any?, continuation: Any?)

    override fun Swift_peer(): Long = Swift_peer

    @androidx.annotation.Keep
    companion object {
    }
}

/// A Swift-backed suspending `kotlin.jvm.functions.Function3` implementor.
class SwiftBackedSuspendFunction3<P0, P1, P2, R>: kotlin.jvm.functions.Function4<P0, P1, P2, kotlin.coroutines.Continuation<R>, Any?>, SwiftPeerBridged {
    private var Swift_peer: Long

    constructor(Swift_peer: Long) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: Long)

    override fun invoke(p0: P0, p1: P1, p2: P2, continuation: kotlin.coroutines.Continuation<R>): Any? {
        Swift_invoke(Swift_peer, p0, p1, p2, SwiftContinuationWrapper(continuation))
        return kotlin.coroutines.intrinsics.COROUTINE_SUSPENDED.sref()
    }
    private external fun Swift_invoke(Swift_peer: Long, p0: Any?, p1: Any?, p2: Any?, continuation: Any?)

    override fun Swift_peer(): Long = Swift_peer

    @androidx.annotation.Keep
    companion object {
    }
}

/// A Swift-backed suspending `kotlin.jvm.functions.Function4` implementor.
class SwiftBackedSuspendFunction4<P0, P1, P2, P3, R>: kotlin.jvm.functions.Function5<P0, P1, P2, P3, kotlin.coroutines.Continuation<R>, Any?>, SwiftPeerBridged {
    private var Swift_peer: Long

    constructor(Swift_peer: Long) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: Long)

    override fun invoke(p0: P0, p1: P1, p2: P2, p3: P3, continuation: kotlin.coroutines.Continuation<R>): Any? {
        Swift_invoke(Swift_peer, p0, p1, p2, p3, SwiftContinuationWrapper(continuation))
        return kotlin.coroutines.intrinsics.COROUTINE_SUSPENDED.sref()
    }
    private external fun Swift_invoke(Swift_peer: Long, p0: Any?, p1: Any?, p2: Any?, p3: Any?, continuation: Any?)

    override fun Swift_peer(): Long = Swift_peer

    @androidx.annotation.Keep
    companion object {
    }
}

/// A Swift-backed suspending `kotlin.jvm.functions.Function5` implementor.
class SwiftBackedSuspendFunction5<P0, P1, P2, P3, P4, R>: kotlin.jvm.functions.Function6<P0, P1, P2, P3, P4, kotlin.coroutines.Continuation<R>, Any?>, SwiftPeerBridged {
    private var Swift_peer: Long

    constructor(Swift_peer: Long) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: Long)

    override fun invoke(p0: P0, p1: P1, p2: P2, p3: P3, p4: P4, continuation: kotlin.coroutines.Continuation<R>): Any? {
        Swift_invoke(Swift_peer, p0, p1, p2, p3, p4, SwiftContinuationWrapper(continuation))
        return kotlin.coroutines.intrinsics.COROUTINE_SUSPENDED.sref()
    }
    private external fun Swift_invoke(Swift_peer: Long, p0: Any?, p1: Any?, p2: Any?, p3: Any?, p4: Any?, continuation: Any?)

    override fun Swift_peer(): Long = Swift_peer

    @androidx.annotation.Keep
    companion object {
    }
}

