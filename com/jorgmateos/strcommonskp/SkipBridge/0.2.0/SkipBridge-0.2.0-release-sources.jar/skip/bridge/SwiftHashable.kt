package skip.bridge

import skip.lib.*



class SwiftHashable: SwiftPeerBridged, skip.lib.SwiftProjecting {
    internal var Swift_peer: Long = SwiftObjectNil

    constructor(Swift_peer: Long) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: Long)

    override fun Swift_peer(): Long = Swift_peer

    override fun equals(other: Any?): Boolean {
        if (!(other is SwiftHashable)) {
            return false
        }
        return Swift_equals(Swift_peer, other.Swift_peer())
    }
    private external fun Swift_equals(Swift_peer: Long, other: Long): Boolean

    override fun hashCode(): Int = Swift_hashCode(Swift_peer).toInt()
    private external fun Swift_hashCode(Swift_peer: Long): Long

    override fun toString(): String = Swift_description(Swift_peer)
    private external fun Swift_description(Swift_peer: Long): String

    override fun Swift_projection(options: Int): () -> Any = Swift_projectionImpl(options)
    private external fun Swift_projectionImpl(options: Int): () -> Any

    @androidx.annotation.Keep
    companion object {
    }
}

