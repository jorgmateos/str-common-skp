package skip.bridge

import skip.lib.*
import skip.lib.Set





/// The libraries we have already loaded, so we don't try to load them again
private var loadedLibraries: Set<String> = setOf()
    get() = field.sref({ loadedLibraries = it })
    set(newValue) {
        field = newValue.sref()
    }

/// In order to use JNI to access the Swift side of the bridge, we need to first manually load the library.
/// This only works on macOS; Android will need to load the .so from the embedded jni library path.
///
/// When searching for the library to load, there are four scenarios we need to handle,
/// each of which has different paths that need to be searched:
///
/// 1. Xcode-launched Swift tests where the embedded JVM needs to load the Xcode-created library ("SkipBridgeSamples.framework/SkipBridgeSamples")
/// 2. Xcode-launched Skip gradle tests, where gradle's JVM needs to load the Xcode created-library ("SkipBridgeSamples.framework/SkipBridgeSamples")
/// 3. SwiftPM-launched Swift tests where the embedded JVM needs to load the SwiftPM-created library ("libSkipBridgeSamples.dylib")
/// 4. SwiftPM-launched Skip gradle tests, where gradle's JVM needs to load the SwiftPM-created library ("libSkipBridgeSamples.dylib")
fun loadPeerLibrary(packageName: String, moduleName: String) {
    val libName = moduleName
    val env = System.getenv()
    //print("System.getenv(): \(env.toSortedMap())")

    // Xcode output for dynamic library
    // user.dir: ~/Developer/Xcode/DerivedData/ProjectName/SourcePackages/plugins/skip-jni.output/SkipBridgeSamplesTests/skipstone/SkipBridgeSamples
    // framework dylib: ~/Library/Developer/Xcode/DerivedData/ProjectName/Build/Products/Debug/PackageFrameworks/SkipBridgeSamples.framework/Versions/A/SkipBridgeSamples

    // XCTestBundlePath=/Users/marc/Library/Developer/Xcode/DerivedData/Skip-Everything-aqywrhrzhkbvfseiqgxuufbdwdft/Build/Products/Debug/SkipBridgeSamplesTests.xctest

    // on an Android device this will be something like "google/sdk_gphone64_arm64/emu64a:14/UE1A.230829.050/12077443:userdebug/dev-keys"
    val isRobolectric = android.os.Build.FINGERPRINT == "robolectric" || android.os.Build.FINGERPRINT == null

    if (!isRobolectric) {
        // we are running on Android, which means the library is packaged with the APK, so we should be able to simply load it by name
        System.loadLibrary(libName)
        return
    }

    // running in Robolectric means we have to search around the file system for where the .dylib is output
    val osName = System.getProperty("os.name")
    val osArch = System.getProperty("os.arch")
    val libext: String
    val arch: String
    val swiftBuildProducts: String
    if (osName.lowercase().contains("linux")) {
        libext = "so"
        arch = if (osArch == "aarch64") "aarch64-unknown-linux-gnu" else "x86_64-unknown-linux-gnu"
        swiftBuildProducts = if (osArch == "aarch64") "Debug-linux-aarch64" else "Debug-linux-x86_64"
    } else {
        libext = "dylib"
        arch = if (osArch == "aarch64") "arm64-apple-macosx" else "x86_64-apple-macosx"
        swiftBuildProducts = "Debug"
    }
    val sharedObject = "lib${libName}.${libext}"
    val libPath = ".build/${libName}/swift/${arch}/debug/${sharedObject}"
    // swiftbuild, SwiftPM's default build system from Swift 6.4, writes products to out/Products/<configuration> rather than <triple>/debug
    val swiftBuildLibPath = ".build/${libName}/swift/out/Products/${swiftBuildProducts}/${sharedObject}"

    val cwd = System.getProperty("user.dir")

    var libraryPath: String
    val matchtarget_0 = env["XCTestBundlePath"]
    if (matchtarget_0 != null) {
        val testBundlePath = matchtarget_0
        // cwd from Xcode: /Users/marc/Library/Developer/Xcode/DerivedData/Skip-Everything-aqywrhrzhkbvfseiqgxuufbdwdft/SourcePackages/plugins/skip-bridge.output/SkipBridgeSamplesTests/skipstone
        // libraryPath = cwd + "/../../../\(libName)/skipstone/\(libName)/" + libPath
        libraryPath = cwd + "/" + libPath
    } else {
        // need to update for forked swift build output

        // cwd from swiftPM CLI: /opt/src/github/skiptools/skip-bridge/.build/plugins/outputs/skip-bridge/SkipBridgeSamplesTests/destination/skipstone/SkipBridgeSamples
        libraryPath = cwd + "/" + libPath
    }
    // swiftbuild's output wins: a native-engine library left behind from before an upgrade must not shadow it
    if (java.io.File(cwd + "/" + swiftBuildLibPath).isFile()) {
        libraryPath = cwd + "/" + swiftBuildLibPath
    }

    if (loadedLibraries.contains(libraryPath)) {
        print("note: already loaded library: ${libraryPath}")
        return
    } else if (!java.io.File(libraryPath).isFile()) {
        // load the native library that contains the function implementations
        error("error: missing library: ${libraryPath}")
    } else {
        print("note: loading library: ${libraryPath}")
        System.load(libraryPath)
        print("note: loaded library: ${libraryPath}")
        loadedLibraries.insert(libraryPath)
    }
}

