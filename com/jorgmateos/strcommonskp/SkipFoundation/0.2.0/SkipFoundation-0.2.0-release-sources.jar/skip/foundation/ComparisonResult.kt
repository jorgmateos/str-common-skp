package skip.foundation

import skip.lib.*

// Copyright 2023–2026 Skip
// SPDX-License-Identifier: MPL-2.0

enum class ComparisonResult(override val rawValue: Int, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): RawRepresentable<Int> {
    orderedAscending(-1),
    orderedSame(0),
    orderedDescending(1);

    @androidx.annotation.Keep
    companion object {

        val ascending: ComparisonResult
            get() = ComparisonResult.orderedAscending
        val same: ComparisonResult
            get() = ComparisonResult.orderedSame
        val descending: ComparisonResult
            get() = ComparisonResult.orderedDescending

        fun init(rawValue: Int): ComparisonResult? {
            return when (rawValue) {
                -1 -> ComparisonResult.orderedAscending
                0 -> ComparisonResult.orderedSame
                1 -> ComparisonResult.orderedDescending
                else -> null
            }
        }
    }
}

fun ComparisonResult(rawValue: Int): ComparisonResult? = ComparisonResult.init(rawValue = rawValue)
