package skip.foundation

import skip.lib.*

// Copyright 2023–2026 Skip
// SPDX-License-Identifier: MPL-2.0

class StringEncoding: RawRepresentable<java.nio.charset.Charset> {

    override val rawValue: java.nio.charset.Charset

    constructor(rawValue: java.nio.charset.Charset, @Suppress("UNUSED_PARAMETER") unusedp_0: Nothing? = null) {
        this.rawValue = rawValue.sref()
    }

    constructor(rawValue: java.nio.charset.Charset) {
        this.rawValue = rawValue.sref()
    }

    val description: String
        get() = rawValue.description

    override fun equals(other: Any?): Boolean {
        if (other !is StringEncoding) return false
        return rawValue == other.rawValue
    }

    override fun hashCode(): Int {
        var result = 1
        result = Hasher.combine(result, rawValue)
        return result
    }

    @androidx.annotation.Keep
    companion object {
        val utf8 = StringEncoding(rawValue = Charsets.UTF_8)
        val utf16 = StringEncoding(rawValue = Charsets.UTF_16)
        val utf16LittleEndian = StringEncoding(rawValue = Charsets.UTF_16LE)
        val utf16BigEndian = StringEncoding(rawValue = Charsets.UTF_16BE)
        val utf32 = StringEncoding(rawValue = Charsets.UTF_32)
        val utf32LittleEndian = StringEncoding(rawValue = Charsets.UTF_32LE)
        val utf32BigEndian = StringEncoding(rawValue = Charsets.UTF_32BE)
    }
}

